import React from "react";
import Header from "./Header";

const Register = () => {
  return (
    <>
    <Header/>
    <div>
      <h1>Register Page</h1>     
    </div>
    </>
  );
};
  
export default Register;