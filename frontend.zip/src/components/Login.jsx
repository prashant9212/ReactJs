import React from "react";
import Header from "./Header";

const Login = () => {
  return (
    <>
    <Header/>
    <div>
      <h1>Login Page</h1>     
    </div>
    </>
  );
};
  

export default Login;