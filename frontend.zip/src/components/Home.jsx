import React, { Component } from 'react'

class Home extends Component {
  // constructor(props) {
  //   super(props);
  //   this.props=props;
  //   console.log(this); // this logged to console
  // }

  constructor(props) {
    super(props);

    this.state = {
        items: [],
        DataisLoaded: false
    };
}
componentDidMount() {
  fetch("https://gorest.co.in/public/v2/users")
      .then((res) => res.json())
      .then((json) => {
          this.setState({
              items: json,
              DataisLoaded: true
          });
      })
}

  render() {
    return(
    // <div>Hello {this.props.Name}, {this.props.Age} Year, {this.props.Address}</div>
    <div className = "App">
    <h1 className="UserListHead"> User Data List </h1>  {
        items.map((item) => (                
            <ul  key = { item.id } className="UserList1">
                <li> ID : { item.id }</li>
                <li> Name : { item.name}</li>
                <li> Email : { item.email }</li>
                <li> Gender : { item.gender }</li>
                <li> Status : { item.status }</li>
            </ul>
        ))
    }
</div>
    );    
  }
}
 
export default Home;
