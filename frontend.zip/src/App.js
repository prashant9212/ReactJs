import './App.css';
import React from 'react';
import Home from './components/Home';

function App() {

  return (
     <>       
        <Home Name="Prashant Chauhan" Age="30" Address="Greate Noida, UP" />
        <Home Name="Mr Chauhan" Age="28" Address="Noida, UP" />
     </>
  );
}

export default App;
